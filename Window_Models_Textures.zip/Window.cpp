#include "Window.h"

Window::Window()
{
	width = 800;
	height = 600;
	muevex = 2.0f;
	rotax = 0.0f;
	rotay = 0.0f;
	rotaz = 0.0f;

	articulacion1 = articulacion2 = articulacion3 = 0.0f;
	articulacion4 = articulacion5 = articulacion6 = 0.0f;
	articulacion7 = articulacion8 = articulacion9 = 0.0f;
	articulacion10 = articulacion11 = articulacion12 = 0.0f;
	articulacion13 = articulacion14 = articulacion15 = 0.0f;
	articulacion16 = articulacion17 = articulacion18 = 0.0f;

	xChange = 0.0f;
	yChange = 0.0f;
	mouseFirstMoved = true;

	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = false;
	}
}

Window::Window(GLint windowWidth, GLint windowHeight)
{
	width = windowWidth;
	height = windowHeight;
	muevex = 2.0f;
	rotax = 0.0f;
	rotay = 0.0f;
	rotaz = 0.0f;
	avionY = 0.0f;
	avionZ = 0.0f;
	naveZ = 0.0f;

	arregloLuces = 0;
	colorFaro = 0;
	luzHolocron = true;
	luzPinza = true;
	luzNave = true;
	estadoMotores = 1;

	articulacion1 = articulacion2 = articulacion3 = 0.0f;
	articulacion4 = articulacion5 = articulacion6 = 0.0f;
	articulacion7 = articulacion8 = articulacion9 = 0.0f;
	articulacion10 = articulacion11 = articulacion12 = 0.0f;
	articulacion13 = articulacion14 = articulacion15 = 0.0f;
	articulacion16 = articulacion17 = articulacion18 = 0.0f;

	xChange = 0.0f;
	yChange = 0.0f;
	mouseFirstMoved = true;

	for (size_t i = 0; i < 1024; i++)
	{
		keys[i] = false;
	}
}

int Window::Initialise()
{
	// Inicializaci�n de GLFW
	if (!glfwInit())
	{
		printf("Fallo al inicializar GLFW\n");
		glfwTerminate();
		return 1;
	}

	// Configuraci�n de versi�n y perfil core de OpenGL
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);

	// Crear ventana
	mainWindow = glfwCreateWindow(width, height, "E09-320309203", NULL, NULL);

	if (!mainWindow)
	{
		printf("Fallo al crear la ventana con GLFW\n");
		glfwTerminate();
		return 1;
	}

	// Obtener tama�o de Buffer
	glfwGetFramebufferSize(mainWindow, &bufferWidth, &bufferHeight);

	// Asignar el contexto actual
	glfwMakeContextCurrent(mainWindow);

	// Configurar callbacks de teclado y mouse
	createCallbacks();

	// Habilitar extensiones modernas
	glewExperimental = GL_TRUE;

	if (glewInit() != GLEW_OK)
	{
		printf("Fallo inicializacion de GLEW\n");
		glfwDestroyWindow(mainWindow);
		glfwTerminate();
		return 1;
	}

	// Habilitar buffer de profundidad
	glEnable(GL_DEPTH_TEST);

	// Asignar Viewport
	glViewport(0, 0, bufferWidth, bufferHeight);

	// Guardar puntero de la instancia en GLFW
	glfwSetWindowUserPointer(mainWindow, this);

	return 0;
}

void Window::createCallbacks()
{
	glfwSetKeyCallback(mainWindow, ManejaTeclado);
	glfwSetCursorPosCallback(mainWindow, ManejaMouse);
}

GLfloat Window::getXChange()
{
	GLfloat theChange = xChange;
	xChange = 0.0f;
	return theChange;
}

GLfloat Window::getYChange()
{
	GLfloat theChange = yChange;
	yChange = 0.0f;
	return theChange;
}

void Window::ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}

	// -------------------------------------------------------------
	// Control de movimiento / traslaci�n (muevex)
	// Se usan flechas (LEFT / RIGHT) para no colisionar con articulaciones
	// -------------------------------------------------------------
	if ((key == GLFW_KEY_RIGHT || key == GLFW_KEY_RIGHT_BRACKET) && (action == GLFW_PRESS || action == GLFW_REPEAT))
	{
		theWindow->muevex += 1.0f;
	}
	if ((key == GLFW_KEY_LEFT || key == GLFW_KEY_LEFT_BRACKET) && (action == GLFW_PRESS || action == GLFW_REPEAT))
	{
		theWindow->muevex -= 1.0f;
	}
	// Helic�ptero
	if ((key == GLFW_KEY_UP || key == GLFW_KEY_PAGE_UP) && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->avionY += 0.5f;
	if ((key == GLFW_KEY_DOWN || key == GLFW_KEY_PAGE_DOWN) && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->avionY -= 0.5f;
	if (key == GLFW_KEY_N && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->avionZ += 0.5f;
	if (key == GLFW_KEY_M && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->avionZ -= 0.5f;

	// Nave
	if (key == GLFW_KEY_COMMA && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->naveZ += 0.5f;
	if (key == GLFW_KEY_PERIOD && (action == GLFW_PRESS || action == GLFW_REPEAT))
		theWindow->naveZ -= 0.5f;

	// 8 = luces de la nave, 9 = motor 1, 0 = motor 2
	if (key == GLFW_KEY_8 && action == GLFW_PRESS) theWindow->luzNave = !theWindow->luzNave;
	if (key == GLFW_KEY_9 && action == GLFW_PRESS)
		theWindow->estadoMotores = (theWindow->estadoMotores + 1) % 4;

	// -------------------------------------------------------------
	// Rotaciones globales
	// -------------------------------------------------------------
	if (key == GLFW_KEY_1 && (action == GLFW_PRESS || action == GLFW_REPEAT))
	{
		theWindow->rotax += 10.0f;
	}
	if (key == GLFW_KEY_2 && (action == GLFW_PRESS || action == GLFW_REPEAT))
	{
		theWindow->rotay += 10.0f;
	}
	if (key == GLFW_KEY_3 && (action == GLFW_PRESS || action == GLFW_REPEAT))
	{
		theWindow->rotaz += 10.0f;
	}

	// Elegir arreglo de luces puntuales: 4 = arreglo 1, 5 = arreglo 2
	if (key == GLFW_KEY_4 && action == GLFW_PRESS) theWindow->arregloLuces = 0;
	if (key == GLFW_KEY_5 && action == GLFW_PRESS) theWindow->arregloLuces = 1;


	//cambia el color del faro del helic�ptero 
	if (key == GLFW_KEY_B && action == GLFW_PRESS)
		theWindow->colorFaro = (theWindow->colorFaro + 1) % 6;

	if (key == GLFW_KEY_6 && action == GLFW_PRESS) theWindow->luzHolocron = !theWindow->luzHolocron;
	if (key == GLFW_KEY_7 && action == GLFW_PRESS) theWindow->luzPinza = !theWindow->luzPinza;

	// -------------------------------------------------------------
	// Articulaciones
	// -------------------------------------------------------------
	if (key == GLFW_KEY_F && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion1 += 10.0f;
	if (key == GLFW_KEY_G && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion2 += 10.0f;
	if (key == GLFW_KEY_H && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion3 += 10.0f;
	if (key == GLFW_KEY_J && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion4 += 10.0f;
	if (key == GLFW_KEY_K && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion5 += 10.0f;
	if (key == GLFW_KEY_L && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion6 += 10.0f;

	if (key == GLFW_KEY_E && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion7 += 10.0f;
	if (key == GLFW_KEY_R && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion8 += 10.0f;
	if (key == GLFW_KEY_P && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion9 += 10.0f;
	if (key == GLFW_KEY_O && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion10 += 10.0f;
	if (key == GLFW_KEY_I && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion11 += 10.0f;
	if (key == GLFW_KEY_U && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion12 += 10.0f;
	if (key == GLFW_KEY_Y && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion13 += 10.0f;
	if (key == GLFW_KEY_T && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion14 += 10.0f;

	if (key == GLFW_KEY_Z && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion15 += 10.0f;
	if (key == GLFW_KEY_X && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion16 += 10.0f;
	if (key == GLFW_KEY_C && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion17 += 10.0f;
	if (key == GLFW_KEY_V && (action == GLFW_PRESS || action == GLFW_REPEAT)) theWindow->articulacion18 += 10.0f;



	// Registro de buffer general de teclas para getKeys()
	if (key >= 0 && key < 1024)
	{
		if (action == GLFW_PRESS)
		{
			theWindow->keys[key] = true;
		}
		else if (action == GLFW_RELEASE)
		{
			theWindow->keys[key] = false;
		}
	}
}

void Window::ManejaMouse(GLFWwindow* window, double xPos, double yPos)
{
	Window* theWindow = static_cast<Window*>(glfwGetWindowUserPointer(window));

	if (theWindow->mouseFirstMoved)
	{
		theWindow->lastX = (GLfloat)xPos;
		theWindow->lastY = (GLfloat)yPos;
		theWindow->mouseFirstMoved = false;
	}

	theWindow->xChange = (GLfloat)xPos - theWindow->lastX;
	theWindow->yChange = theWindow->lastY - (GLfloat)yPos;

	theWindow->lastX = (GLfloat)xPos;
	theWindow->lastY = (GLfloat)yPos;
}

Window::~Window()
{
	glfwDestroyWindow(mainWindow);
	glfwTerminate();
}