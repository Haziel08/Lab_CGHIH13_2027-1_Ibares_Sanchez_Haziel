#pragma once
#include <stdio.h>
#include <glew.h>
#include <glfw3.h>

class Window
{
public:
	Window();
	Window(GLint windowWidth, GLint windowHeight);
	int Initialise();

	// Buffers y estado de la ventana
	GLfloat getBufferWidth() { return bufferWidth; }
	GLfloat getBufferHeight() { return bufferHeight; }
	bool getShouldClose() { return glfwWindowShouldClose(mainWindow); }
	bool* getsKeys() { return keys; }
	GLfloat getXChange();
	GLfloat getYChange();
	void swapBuffers() { glfwSwapBuffers(mainWindow); }

	// Traslación general
	GLfloat getmuevex() { return muevex; }
	GLfloat getavionY() { return avionY; }
	GLfloat getavionZ() { return avionZ; }
	GLfloat getnaveZ() { return naveZ; }

	GLint getarregloLuces() { return arregloLuces; }
	GLint getcolorFaro() { return colorFaro; }
	bool getluzHolocron() { return luzHolocron; }
	bool getluzPinza() { return luzPinza; }
	bool getluzNave() { return luzNave; }
	bool getmotor1() { return estadoMotores == 1 || estadoMotores == 3; }
	bool getmotor2() { return estadoMotores == 1 || estadoMotores == 2; }

	// Rotaciones generales
	GLfloat getrotax() { return rotax; }
	GLfloat getrotay() { return rotay; }
	GLfloat getrotaz() { return rotaz; }

	// Articulaciones
	GLfloat getarticulacion1() { return articulacion1; }
	GLfloat getarticulacion2() { return articulacion2; }
	GLfloat getarticulacion3() { return articulacion3; }
	GLfloat getarticulacion4() { return articulacion4; }
	GLfloat getarticulacion5() { return articulacion5; }
	GLfloat getarticulacion6() { return articulacion6; }
	GLfloat getarticulacion7() { return articulacion7; }
	GLfloat getarticulacion8() { return articulacion8; }
	GLfloat getarticulacion9() { return articulacion9; }
	GLfloat getarticulacion10() { return articulacion10; }
	GLfloat getarticulacion11() { return articulacion11; }
	GLfloat getarticulacion12() { return articulacion12; }
	GLfloat getarticulacion13() { return articulacion13; }
	GLfloat getarticulacion14() { return articulacion14; }
	GLfloat getarticulacion15() { return articulacion15; }
	GLfloat getarticulacion16() { return articulacion16; }
	GLfloat getarticulacion17() { return articulacion17; }
	GLfloat getarticulacion18() { return articulacion18; }

	~Window();

private:
	GLFWwindow* mainWindow;
	GLint width, height;
	GLint bufferWidth, bufferHeight;

	bool keys[1024];

	GLfloat lastX;
	GLfloat lastY;
	GLfloat xChange;
	GLfloat yChange;
	bool mouseFirstMoved;

	// Variables
	GLfloat muevex;
	GLfloat rotax, rotay, rotaz;
	GLfloat articulacion1, articulacion2, articulacion3, articulacion4, articulacion5, articulacion6;
	GLfloat articulacion7, articulacion8, articulacion9, articulacion10, articulacion11, articulacion12;
	GLfloat articulacion13, articulacion14, articulacion15, articulacion16, articulacion17, articulacion18;
	GLfloat avionY, avionZ;
	GLfloat naveZ;
	GLint arregloLuces;
	GLint colorFaro;
	bool luzHolocron, luzPinza;
	bool luzNave;
	GLint estadoMotores;

	void createCallbacks();
	static void ManejaTeclado(GLFWwindow* window, int key, int code, int action, int mode);
	static void ManejaMouse(GLFWwindow* window, double xPos, double yPos);
};